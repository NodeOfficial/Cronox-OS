# Was ist NodeOS?

NodeOS ist ein minimalistisches Betriebssystem welches Node.js für den "Userspace" benutzt. NodeOS ist vollständig in Javascript gemacht und durch NPM (als Packetmanager) kontrolliert. Jedes Packet dass bei NPM vorhanden ist, ist gleichzeitig auch ein Packet für NodeOS, das heißt dass es 244,180 (nach letzter zählung) potenzielle Packete für NodeOS gibt.

Das Ziel von NodeOS ist grade soviel bereitzustellen damit NPM den rest bereitstellen kann.
Da jeder auf NPM hochladen kann, kann auch jeder ein NodeOS Packet erstellen.