# NodeOS Frequently Asked Questions #
(Or solutions to problems you seem to have often).

Not many questions will be actually answered on this page, but rather linked to the respective page thank explains it to you nicely in detail. Hopefully at the start of the page a tl;dr will sum it all up for you if you don't have time.

Fixing NodeOS Build Errors: [[Fixing-NodeOS-Build-Errors]]

How do I add startup services?: [[Service Starter (PalmTree)]]