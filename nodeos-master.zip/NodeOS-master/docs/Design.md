## Here lies our collective conciousness ##

Even as we discuss everything in the issues, additionally here you will find drafts for concepts and ideas for NodeOS. Feel free to contribute to an idea and should a great idea come across your mind, create a new Thread and page and link one to another!


### Current Designs ###
- [[file system|FileSystem]]
- [[npkg]]
- [[services]]
- [[asgard]]
- [[root]]
- [[init]]