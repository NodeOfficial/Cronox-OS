The `help` command will be there to guide people through node-os.
This is a lot less like `man` and more like a http://nodeschool.io lesson.
